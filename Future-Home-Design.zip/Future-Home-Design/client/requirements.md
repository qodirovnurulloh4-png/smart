## Packages
framer-motion | Complex animations and page transitions

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'Outfit'", "sans-serif"],
  mono: ["'Space Mono'", "monospace"],
  display: ["'Orbitron'", "sans-serif"],
}
